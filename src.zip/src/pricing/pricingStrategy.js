const StandardPricing = require('./standardPricing')
const SeasonalPricing = require('./seasonalPricing')
const WeekendPricing = require('./weekendPricing')

class PricingStrategyFactory {

  static getStrategy(strategy){

    if(!strategy){
      return new StandardPricing()
    }

    const type = strategy.toUpperCase()

    if(type === "STANDARD"){
      return new StandardPricing()
    }

    if(type === "WEEKEND"){
      return new WeekendPricing()
    }

    if(type === "SEASONAL"){
      return new SeasonalPricing()
    }

    return new StandardPricing()

  }

}

module.exports = PricingStrategyFactory