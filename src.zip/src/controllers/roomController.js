
const pool = require("../db/db")

//get route
exports.getRooms = async (req,res)=>{
  try{
    const page = parseInt(req.query.page) || 1
    const limit = parseInt(req.query.limit) || 5
    const search = req.query.search || ""
    const offset = (page - 1) * limit
    const result = await pool.query(
      'select id,roomnumber as "roomNumber",floor,hotel_id as "hotelId",room_type_id as "roomTypeId" from room where roomnumber::text ILIKE $1 order by id asc limit $2 offset $3',
      [`%${search}%`, limit, offset]
    )
    const countResult = await pool.query(
      "select count(*) from room where roomnumber::text ILIKE $1",
      [`%${search}%`]
    )
    const totalRooms = parseInt(countResult.rows[0].count)
    const totalPages = Math.ceil(totalRooms / limit)
    res.json({
      data: result.rows,
      totalPages: totalPages
    })
  }
  catch(err){
    console.error(err)
    res.status(500).send("server error")
  }
}


//post route
exports.createRoom = async (req,res)=>{
  try{
    const {roomNumber,floor,hotelId,roomTypeId} = req.body
    const result = await pool.query(
      "insert into room(roomnumber,floor,hotel_id,room_type_id) values($1,$2,$3,$4) returning *",
      [roomNumber,floor,hotelId,roomTypeId]
    )
    res.json(result.rows[0])
  }
  catch(err){
    console.error(err)
    res.status(500).send("server error")
  }
}

//update
exports.updateRoom = async (req,res)=>{
  try{
    const {id} = req.params
    const {roomNumber,floor,hotelId,roomTypeId} = req.body
    const result = await pool.query(
      "update room set roomnumber=$1,floor=$2,hotel_id=$3,room_type_id=$4 where id=$5 returning *",
      [roomNumber,floor,hotelId,roomTypeId,id]
    )
    res.json(result.rows[0])
  }
  catch(err){
    console.error(err)
    res.status(500).send("server error")
  }
}

//delete route
exports.deleteRoom = async (req,res)=>{
  try{
    const {id} = req.params
    const result = await pool.query(
      "delete from room where id=$1 returning *",
      [id]
    )
    res.json(result.rows[0])
  }
  catch(err){
    console.error(err)
    res.status(500).send("server error")
  }
}