class weekendPricing {
  calculatePrice(basePrice, checkInDate, checkOutDate) {
    const price = parseFloat(basePrice);
    const start = new Date(checkInDate);
    const end = new Date(checkOutDate);
    let total = 0;
    for (let d = new Date(start); d < end; d.setDate(d.getDate() + 1)) {
      const day = d.getDay();
      if (day === 5 || day === 6) {
        total += price * 1.5;
      } 
      else {
        total += price;
      }
    }
    return total;

  }
}
module.exports = weekendPricing;