const pool = require("../db/db");
const PricingStrategyFactory = require("../pricing/pricingStrategy");

class BookingUtils {

  // INITIALIZE BOOKING
  static async initializeBooking(guestName, roomTypeId, checkInDate, checkOutDate) {

    const roomTypeResult = await pool.query(
      "SELECT price, pricing_strategy FROM room_type WHERE id=$1",
      [roomTypeId]
    );

    if (roomTypeResult.rows.length === 0) {
      throw new Error("Room type not found");
    }

    const basePrice = roomTypeResult.rows[0].price;
    const strategyType = roomTypeResult.rows[0].pricing_strategy;

    const strategy = PricingStrategyFactory.getStrategy(strategyType);

    const totalCost = strategy.calculatePrice(
      basePrice,
      checkInDate,
      checkOutDate
)

    const result = await pool.query(
      `INSERT INTO booking 
      (guest_name, room_type_id, check_in_date, check_out_date, total_cost, status)
      VALUES ($1,$2,$3,$4,$5,'INITIALIZED')
      RETURNING *`,
      [guestName, roomTypeId, checkInDate, checkOutDate, totalCost]
    );

    return result.rows[0];
  }


  // CONFIRM BOOKING
  static async confirmBooking(id) {

    const result = await pool.query(
      "SELECT * FROM booking WHERE id=$1",
      [id]
    );

    const booking = result.rows[0];

    if (!booking) {
      throw new Error("Booking not found");
    }

    if (booking.status !== "INITIALIZED") {
      throw new Error("Booking must be INITIALIZED to confirm");
    }

    const update = await pool.query(
      "UPDATE booking SET status='CONFIRMED' WHERE id=$1 RETURNING *",
      [id]
    );

    return update.rows[0];
  }


  // CHECK IN
  static async checkInBooking(id) {

    const result = await pool.query(
      "SELECT * FROM booking WHERE id=$1",
      [id]
    );

    const booking = result.rows[0];

    if (!booking) {
      throw new Error("Booking not found");
    }

    if (booking.status !== "CONFIRMED") {
      throw new Error("Booking must be CONFIRMED to check in");
    }

    const update = await pool.query(
      "UPDATE booking SET status='CHECKED_IN' WHERE id=$1 RETURNING *",
      [id]
    );

    return update.rows[0];
  }


  // CHECK OUT
  static async checkOutBooking(id) {

    const result = await pool.query(
      "SELECT * FROM booking WHERE id=$1",
      [id]
    );

    const booking = result.rows[0];

    if (!booking) {
      throw new Error("Booking not found");
    }

    if (booking.status !== "CHECKED_IN") {
      throw new Error("Booking must be CHECKED_IN to check out");
    }

    const update = await pool.query(
      "UPDATE booking SET status='CHECKED_OUT' WHERE id=$1 RETURNING *",
      [id]
    );

    return update.rows[0];
  }


  // COMPLETE BOOKING
  static async completeBooking(id) {

    const result = await pool.query(
      "SELECT * FROM booking WHERE id=$1",
      [id]
    );

    const booking = result.rows[0];

    if (!booking) {
      throw new Error("Booking not found");
    }

    if (booking.status !== "CHECKED_OUT") {
      throw new Error("Booking must be CHECKED_OUT to complete");
    }

    const update = await pool.query(
      "UPDATE booking SET status='COMPLETED' WHERE id=$1 RETURNING *",
      [id]
    );

    return update.rows[0];
  }

}

module.exports = BookingUtils;