class standardPricing {
  calculatePrice(basePrice, checkInDate, checkOutDate) {
    const price = parseFloat(basePrice);
    const start = new Date(checkInDate);
    const end = new Date(checkOutDate);
    const nights = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    return price * nights;
  }
}
module.exports = standardPricing;