class seasonalPricing {
  calculatePrice(basePrice, checkInDate, checkOutDate) {
    const price = parseFloat(basePrice);
    const start = new Date(checkInDate);
    const end = new Date(checkOutDate);
    let total = 0;
    for (let d = new Date(start); d < end; d.setDate(d.getDate() + 1)) {
      const month = d.getMonth() + 1;
      if (month === 12 || month === 1) {
        total += price * 2;
      }
      else if (month >= 6 && month <= 8) {
        total += price * 1.3;
      }
      else {
        total += price;
      }
    }
    return total;
  }
}
module.exports = seasonalPricing;