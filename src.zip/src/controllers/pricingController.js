const pool = require("../db/db")
const pricingStrategy = require("../pricing/pricingStrategy")

exports.calculatePrice = async (req,res)=>{
  try{

    const { roomTypeId, checkInDate, checkOutDate } = req.body

    const result = await pool.query(
      "select price, pricing_strategy from room_type where id=$1",
      [roomTypeId]
    )

    if(result.rows.length === 0){
      return res.status(404).json({ message: "Room type not found" })
    }

    const basePrice = parseFloat(result.rows[0].price)
    const strategyType = result.rows[0].pricing_strategy

    const strategy = pricingStrategy.getStrategy(strategyType)

    const totalPrice = strategy.calculatePrice(
      basePrice,
      checkInDate,
      checkOutDate
    )

    res.json({
      roomTypeId,
      totalPrice
    })

  }
  catch(err){
    console.error(err)
    res.status(500).send("server error")
  }
}